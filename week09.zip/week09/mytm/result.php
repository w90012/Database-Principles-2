<html>
<head>
<meta charset="utf-8"> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>STITM</title>
</head>
<body>
<?php
    //连接服务器
   $dbhost = "localhost";  //MySQL服务器主机地址
   $dbuser = "root";      //MySQL用户名
   $dbpass = ""; //MySQL用户名密码
   
   $conn = mysqli_connect($dbhost, $dbuser, $dbpass);
 
   if(!$conn)
   {
     echo "连接失败了！！";
   }
   
   mysqli_select_db($conn,"mytm"); //连接数据库
   
   mysqli_query($conn,"set names utf8"); //防止出现中文乱码的情况
   
  
  $query = $_POST["query"]; //获取用户输入的检索词
  
  echo $query;
   
   //选择数据表中的字段
   
   $sql = "SELECT * FROM `stitm` WHERE `zh_CN` LIKE '%{$query}%' or `en_US` LIKE '%{$query}%'";
 
   mysqli_query($conn,"set names utf8"); //防止出现中文乱码的情况
   $result = mysqli_query($conn,$sql);
   
   //var_dump($result);
   
   echo "<table border='1'>
			<tr>
			<td>英文</td>
			<td>中文</td>
			<td>删除</td>
			<td>编辑</td>
			</tr>";
			
   while($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
	{
       echo "<tr><td>".$row["en_US"]."</td>";
	   echo "<td>".$row["zh_CN"]."</td>";
	   echo "<td><a href='delete.php?id={$row["ID"]}'>删除</a></td>";
	   echo "<td><a href='edit.php?id={$row["ID"]}' target='_blank'>编辑</a></td></tr>";
    } 

	echo "</table>";
  
?>
</body>
</html>