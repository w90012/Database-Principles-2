<?php

$id=$_GET["id"];

//连接服务器

$dbhost = "localhost";  //MySQL服务器主机地址
$dbuser = "root";      //MySQL用户名
$dbpass = "pass"; //MySQL用户名密码

$conn = mysqli_connect($dbhost, $dbuser, $dbpass);

if(!$conn)
{
  echo "连接失败了！！";
}

mysqli_select_db($conn,"selfproject"); //连接数据库

mysqli_query($conn,"set names utf8"); //防止出现中文乱码的情况

 //选择数据表中的字段
   
$sql = "SELECT * FROM selfproject WHERE ID={$id}";

mysqli_query($conn,"set names utf8"); //防止出现中文乱码的情况

$result = mysqli_query($conn,$sql);

$row = mysqli_fetch_array($result, MYSQLI_ASSOC);

$title = $row["title"];

$body = $row["body"];

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>全文检索</title>
</head>
<body>

<form method="POST" action="update.php"> 
						
	<table>
		<tr>
			<td>
				类别：<input type="text" name="title" value ="<?php echo $title; ?>" >
			</td>

		</tr>
		
		<tr>
			<td>
				诗句：<input type="text" name="body" value ="<?php echo $body; ?>" >
			</td>
		
		</tr>
		
		<tr>
			<td>
				<input type="hidden" name="id" value ="<?php echo $id; ?>" >
			</td>
		
		</tr>		
		
		<tr>
			<td>
				<button type="submit">更新</button>
			</td>
		</tr>
	
	</table>
		
</form>

</body>
</html>