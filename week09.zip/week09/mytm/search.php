<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>STITM</title>
</head>
<body>

<form method="POST" action="result.php"> 
						
	<table>
		<tr>
			<td>
				检索词：<input type="text" name="query">
			</td>

		</tr>
		
		<tr>
			<td>
				<button type="submit">开始</button>
			</td>
		</tr>
	
	</table>
		
</form>

</body>
</html>