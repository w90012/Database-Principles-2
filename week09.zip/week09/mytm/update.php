<?php

$id = $_POST["id"];
$zh_CN = $_POST["zh_CN"];  
$en_US = $_POST["en_US"];  
  
//连接服务器

$dbhost = "localhost";  //MySQL服务器主机地址
$dbuser = "root";      //MySQL用户名
$dbpass = ""; //MySQL用户名密码

$conn = mysqli_connect($dbhost, $dbuser, $dbpass);

if(!$conn)
{
  echo "连接失败了！！";
}

mysqli_select_db($conn,"mytm"); //连接数据库

mysqli_query($conn,"set names utf8"); //防止出现中文乱码的情况
      
  
//$sql = "INSERT INTO stitm(zh_CN,en_US) VALUES('$zh_CN','$en_US')";  
$sql = "UPDATE `stitm` SET `zh_CN` = '{$zh_CN}', `en_US` = '{$en_US}' WHERE `ID` = {$id}";
               
$update = mysqli_query($conn,$sql);  
  
if(!$update)  
    {  
        echo "无法更新翻译单元: ".mysqli_error($conn);  
    }  
    else  
    {  
        echo "翻译单元更新成功！"."<br>"; 
		echo "<a href='index.php'>查看数据</a>";
    }  

mysqli_close($conn);  
?>