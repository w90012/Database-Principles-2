<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>STITM</title>
</head>
<body>

<form method="POST" action="add.php"> 
						
	<table>
		<tr>
			<td>
				中文：<input type="text" name="zh_CN">
			</td>

		</tr>
		
		<tr>
			<td>
				英文：<input type="text" name="en_US">
			</td>
		
		</tr>
		
		<tr>
			<td>
				<button type="submit">提交</button>
			</td>
		</tr>
	
	</table>
		
</form>

</body>
</html>