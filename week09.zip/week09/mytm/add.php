<?php

$title = $_POST["body"];  
$body = $_POST["body"];  
  
//连接服务器

$dbhost = "localhost";  //MySQL服务器主机地址
$dbuser = "root";      //MySQL用户名
$dbpass = "pass"; //MySQL用户名密码

$conn = mysqli_connect($dbhost, $dbuser, $dbpass);

if(!$conn)
{
  echo "连接失败了！！";
}

mysqli_select_db($conn,"selfproject"); //连接数据库

mysqli_query($conn,"set names utf8"); //防止出现中文乱码的情况
      
  
$sql = "INSERT INTO stitm(title,body) VALUES('$title','$body')";  
               
$insert = mysqli_query($conn,$sql);  
  
if(!$insert)  
    {  
        echo "无法插入翻译单元: ".mysqli_error($conn);  
    }  
    else  
    {  
        echo "翻译单元插入成功！"."<br>"; 
		echo "<a href='index.php'>查看数据</a>";
    }  

mysqli_close($conn);  
?>